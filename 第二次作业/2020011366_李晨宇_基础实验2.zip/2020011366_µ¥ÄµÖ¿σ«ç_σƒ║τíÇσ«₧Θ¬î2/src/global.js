let userInfo = {
    username: 'lichenyu',
    usage: '8.57'
}